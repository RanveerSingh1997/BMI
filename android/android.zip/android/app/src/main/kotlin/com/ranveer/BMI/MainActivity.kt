package com.ranveer.BMI

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
